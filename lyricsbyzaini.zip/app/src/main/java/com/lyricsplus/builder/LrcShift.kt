package com.lyricsplus.builder

/** Geser dan baca timestamp [mm:ss.xx] dalam teks LRC. */
object LrcShift {
    private val TS = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?\\]")

    class Line(val t: Double, val text: String)

    /** deltaSec > 0: lirik muncul lebih lambat. deltaSec < 0: lirik muncul lebih awal. */
    fun shift(lrc: String, deltaSec: Double): String {
        val delta = Math.round(deltaSec * 100).toInt()
        return TS.replace(lrc) { m ->
            val min = m.groupValues[1].toInt()
            val sec = m.groupValues[2].toInt()
            val frac = m.groupValues[3]
            val cs = when (frac.length) {
                0 -> 0
                1 -> frac.toInt() * 10
                2 -> frac.toInt()
                else -> Math.round(frac.toInt() / Math.pow(10.0, (frac.length - 2).toDouble())).toInt()
            }
            var total = (min * 60 + sec) * 100 + cs + delta
            if (total < 0) total = 0
            "[%02d:%02d.%02d]".format(total / 6000, (total / 100) % 60, total % 100)
        }
    }

    /** Baca LRC jadi daftar baris berwaktu (untuk pratinjau). */
    fun parse(lrc: String): List<Line> {
        val out = ArrayList<Line>()
        for (raw in lrc.lines()) {
            val ms = TS.findAll(raw).toList()
            if (ms.isEmpty()) continue
            val text = TS.replace(raw, "").trim()
            for (m in ms) {
                val frac = m.groupValues[3]
                val f = if (frac.isEmpty()) 0.0 else frac.toInt() / Math.pow(10.0, frac.length.toDouble())
                out.add(Line(m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt() + f, text))
            }
        }
        out.sortBy { it.t }
        return out
    }
}
