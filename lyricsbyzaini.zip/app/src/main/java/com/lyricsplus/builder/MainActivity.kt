package com.lyricsplus.builder

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0F0F14")
    private val CARD = Color.parseColor("#1B1B24")
    private val ACCENT = Color.parseColor("#7C5CFF")
    private val MUTED = Color.parseColor("#9A9AAE")

    private var addonUri: Uri? = null
    private var audioUri: Uri? = null
    private var audioSec = 0
    private var outUri: Uri? = null
    private var outName = ""
    private var shiftTotal = 0.0
    private var player: MediaPlayer? = null
    private var seeking = false
    private var parsedText = ""
    private var parsed: List<LrcShift.Line> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private val tick: Runnable = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (!seeking) seek.progress = p.currentPosition
            refreshPreview()
            if (p.isPlaying) handler.postDelayed(this, 100)
        }
    }

    private lateinit var addonStatus: TextView
    private lateinit var audioStatus: TextView
    private lateinit var lyricStatus: TextView
    private lateinit var shiftLabel: TextView
    private lateinit var playBtn: Button
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var prevTv: TextView
    private lateinit var curTv: TextView
    private lateinit var nextTv: TextView
    private lateinit var buildStatus: TextView
    private lateinit var titleEt: EditText
    private lateinit var artistEt: EditText
    private lateinit var lrcEt: EditText
    private lateinit var ecoCb: CheckBox
    private lateinit var bar: ProgressBar
    private lateinit var buildBtn: Button
    private lateinit var openBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private enum class Kind { PRIMARY, SECONDARY, SUCCESS }

    private fun button(t: String, kind: Kind = Kind.SECONDARY, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        minHeight = dp(48)
        minimumHeight = dp(48)
        setPadding(dp(14), 0, dp(14), 0)
        stateListAnimator = null
        val fill = when (kind) {
            Kind.PRIMARY -> ACCENT
            Kind.SUCCESS -> Color.parseColor("#2E9E5B")
            Kind.SECONDARY -> Color.parseColor("#2A2A38")
        }
        val shape = rounded(fill, 12)
        if (kind == Kind.SECONDARY) shape.setStroke(dp(1), Color.parseColor("#3D3D52"))
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), shape, null)
        setOnClickListener { onClick() }
    }

    private fun edit(hintText: String, multiline: Boolean = false) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.parseColor("#666677"))
        setTextColor(Color.WHITE)
        background = rounded(Color.parseColor("#12121A"), 10)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        minHeight = dp(48)
        if (multiline) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 8
            gravity = Gravity.TOP
        } else {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
    }

    private fun card(root: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = rounded(CARD, 16)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        root.addView(c, lp)
        c.addView(label(title, 16f, Color.WHITE, true))
        return c
    }

    private fun gap(parent: LinearLayout, h: Int = 8) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        val chip = label("Lyrics by Zaini", 12f, Color.parseColor("#C9BEFF"), true).apply {
            letterSpacing = 0.05f
            background = rounded(Color.parseColor("#26204D"), 20)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        root.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        gap(root, 12)
        root.addView(label("LyricsPlus Builder", 24f, Color.WHITE, true))
        root.addView(label("Tambah lagu + lirik ke add-on LyricsPlus lu. Lirik dicari online, hasilnya dipakai offline di Minecraft.", 13f, MUTED))
        gap(root, 16)

        // 1. Add-on
        val c1 = card(root, "1. Add-on LyricsPlus")
        addonStatus = label("Belum dipilih (file .mcaddon)", 13f, MUTED)
        gap(c1)
        c1.addView(button("Pilih file .mcaddon") { pick(1, "*/*") })
        gap(c1, 8)
        c1.addView(addonStatus)

        // 2. Lagu
        val c2 = card(root, "2. Lagu (file audio di HP lu)")
        audioStatus = label("Belum dipilih (mp3, m4a, ogg, wav...)", 13f, MUTED)
        gap(c2)
        c2.addView(button("Pilih file lagu") { pick(2, "audio/*") })
        gap(c2, 8)
        c2.addView(audioStatus)
        gap(c2)
        titleEt = edit("Judul lagu")
        c2.addView(titleEt)
        gap(c2, 8)
        artistEt = edit("Artis")
        c2.addView(artistEt)
        gap(c2, 8)
        ecoCb = CheckBox(this).apply {
            text = "Hemat ukuran (mono 22 kHz, file jauh lebih kecil)"
            setTextColor(Color.WHITE)
            textSize = 13f
        }
        c2.addView(ecoCb)

        // 3. Lirik
        val c3 = card(root, "3. Lirik berwaktu")
        gap(c3)
        c3.addView(button("Cari lirik online") { searchLyrics() })
        gap(c3, 8)
        lyricStatus = label("Atau tempel lirik format LRC sendiri di bawah.", 13f, MUTED)
        c3.addView(lyricStatus)
        gap(c3)
        lrcEt = edit("[00:12.50] baris lirik pertama\n[00:16.00] baris kedua", true)
        c3.addView(lrcEt)

        // Pratinjau: putar lagu + lirik jalan + geser timing
        val cp = card(root, "Pratinjau dan atur timing")
        cp.addView(label("Putar lagunya, lihat liriknya jalan, lalu geser timing sampai pas.", 12f, MUTED))
        gap(cp)
        playBtn = button("Putar", Kind.PRIMARY) { togglePlay() }
        cp.addView(playBtn)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (fromUser) {
                    player?.seekTo(v)
                    refreshPreview()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                seeking = false
            }
        })
        cp.addView(seek)
        timeTv = label("00:00 / 00:00", 12f, MUTED)
        cp.addView(timeTv)
        gap(cp, 10)
        prevTv = label("", 13f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 2 }
        curTv = label("", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER; minLines = 2; maxLines = 3 }
        nextTv = label("", 13f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 2 }
        cp.addView(prevTv)
        cp.addView(curTv)
        cp.addView(nextTv)
        gap(cp, 10)
        cp.addView(label("Geser waktu lirik", 14f, Color.WHITE, true))
        cp.addView(label("Lambat = lirik muncul lebih telat. Lebih awal = lirik muncul lebih cepat.", 12f, MUTED))
        shiftLabel = label("Sudah digeser: 0.0 dtk", 12f, MUTED)
        cp.addView(shiftLabel)
        gap(cp, 8)
        cp.addView(shiftRow("Lebih awal 1" to -1.0, "Lambat 1" to 1.0))
        gap(cp, 8)
        cp.addView(shiftRow("Lebih awal 0.5" to -0.5, "Lambat 0.5" to 0.5))
        gap(cp, 8)
        cp.addView(shiftRow("Lebih awal 0.1" to -0.1, "Lambat 0.1" to 0.1))

        // 4. Bangun
        val c4 = card(root, "4. Bangun add-on")
        gap(c4)
        buildBtn = button("Bangun add-on", Kind.PRIMARY) { build() }
        c4.addView(buildBtn)
        gap(c4, 8)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        c4.addView(bar)
        buildStatus = label("", 13f, MUTED)
        c4.addView(buildStatus)
        gap(c4)
        openBtn = button("Buka di Minecraft", Kind.SUCCESS) { openInMinecraft() }
        openBtn.visibility = View.GONE
        c4.addView(openBtn)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }

    private fun fmt(ms: Int) = "%02d:%02d".format(ms / 60000, (ms / 1000) % 60)

    private fun showLyric(sec: Double) {
        val cur = lrcEt.text.toString()
        if (cur != parsedText) {
            parsedText = cur
            parsed = LrcShift.parse(cur)
        }
        val ls = parsed
        if (ls.isEmpty()) {
            prevTv.text = ""
            curTv.text = "(lirik kosong atau bukan format LRC)"
            nextTv.text = ""
            return
        }
        var idx = -1
        for (i in ls.indices) {
            if (ls[i].t <= sec) idx = i else break
        }
        fun txt(i: Int): String = if (i in ls.indices) ls[i].text.ifBlank { "..." } else ""
        prevTv.text = txt(idx - 1)
        curTv.text = if (idx < 0) "..." else txt(idx)
        nextTv.text = txt(idx + 1)
    }

    private fun refreshPreview() {
        val p = player ?: return
        val pos = p.currentPosition
        timeTv.text = fmt(pos) + " / " + fmt(p.duration)
        showLyric(pos / 1000.0)
    }

    private fun ensurePlayer(): MediaPlayer? {
        player?.let { return it }
        val u = audioUri ?: run {
            toast("Pilih file lagu dulu")
            return null
        }
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, u)
            mp.prepare()
            mp.setOnCompletionListener {
                handler.removeCallbacks(tick)
                playBtn.text = "Putar"
                refreshPreview()
            }
            player = mp
            seek.max = mp.duration
            mp
        } catch (e: Exception) {
            toast("Gagal memutar lagu: ${e.message}")
            null
        }
    }

    private fun togglePlay() {
        val p = ensurePlayer() ?: return
        if (p.isPlaying) {
            p.pause()
            handler.removeCallbacks(tick)
            playBtn.text = "Putar"
            refreshPreview()
        } else {
            if (p.currentPosition >= p.duration - 200) p.seekTo(0)
            p.start()
            playBtn.text = "Jeda"
            handler.post(tick)
        }
    }

    private fun releasePlayer() {
        handler.removeCallbacks(tick)
        try { player?.release() } catch (_: Exception) {}
        player = null
        playBtn.text = "Putar"
        seek.progress = 0
        timeTv.text = "00:00 / 00:00"
        prevTv.text = ""
        curTv.text = ""
        nextTv.text = ""
    }

    override fun onPause() {
        super.onPause()
        val p = player
        if (p != null && p.isPlaying) {
            p.pause()
            handler.removeCallbacks(tick)
            playBtn.text = "Putar"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { player?.release() } catch (_: Exception) {}
        player = null
        super.onDestroy()
    }

    private fun shiftRow(a: Pair<String, Double>, b: Pair<String, Double>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, p) in listOf(a, b).withIndex()) {
            val btn = button(p.first) { shiftLyrics(p.second) }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i == 0) lp.rightMargin = dp(8)
            row.addView(btn, lp)
        }
        return row
    }

    private fun shiftLyrics(d: Double) {
        val cur = lrcEt.text.toString()
        if (cur.isBlank()) {
            toast("Lirik masih kosong")
            return
        }
        lrcEt.setText(LrcShift.shift(cur, d))
        shiftTotal += d
        val sign = if (shiftTotal > 0.001) "+" else ""
        shiftLabel.text = "Sudah digeser: " + sign + "%.1f".format(shiftTotal) + " dtk"
        refreshPreview()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---------- Pilih file ----------
    private fun pick(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, code)
    }

    private fun nameOf(u: Uri): String {
        contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "file"
        }
        return "file"
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val u = data?.data ?: return
        when (requestCode) {
            1 -> {
                addonUri = u
                addonStatus.text = "Dipilih: " + nameOf(u)
            }
            2 -> {
                releasePlayer()
                audioUri = u
                val fileName = nameOf(u)
                audioStatus.text = "Dipilih: $fileName"
                var t: String? = null
                var a: String? = null
                var ms = 0L
                val mr = MediaMetadataRetriever()
                try {
                    mr.setDataSource(this, u)
                    t = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    a = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ms = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                } finally {
                    try { mr.release() } catch (_: Exception) {}
                }
                audioSec = (ms / 1000).toInt()
                titleEt.setText(if (!t.isNullOrBlank()) t else fileName.substringBeforeLast('.'))
                if (!a.isNullOrBlank()) artistEt.setText(a)
            }
        }
    }

    // ---------- Cari lirik ----------
    private fun searchLyrics() {
        val t = titleEt.text.toString().trim()
        val a = artistEt.text.toString().trim()
        if (t.isEmpty()) {
            toast("Isi judul lagu dulu")
            return
        }
        lyricStatus.text = "Mencari lirik..."
        thread {
            try {
                val f = Lrclib.find(t, a, audioSec)
                runOnUiThread {
                    if (f == null) {
                        lyricStatus.text = "Lirik berwaktu nggak ketemu. Coba ubah judul/artis, atau tempel LRC manual."
                    } else {
                        lrcEt.setText(f.synced)
                        shiftTotal = 0.0
                        refreshPreview()
                        shiftLabel.text = "Sudah digeser: 0.0 dtk"
                        lyricStatus.text = "Ketemu: ${f.artist} - ${f.title}"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { lyricStatus.text = "Gagal cari lirik: ${e.message}" }
            }
        }
    }

    // ---------- Bangun ----------
    private fun status(m: String) = runOnUiThread { buildStatus.text = m }

    private fun build() {
        val ad = addonUri
        val au = audioUri
        if (ad == null) {
            toast("Pilih file add-on dulu")
            return
        }
        if (au == null) {
            toast("Pilih file lagu dulu")
            return
        }
        val title = titleEt.text.toString().trim()
        val artist = artistEt.text.toString().trim()
        val lrc = lrcEt.text.toString()
        if (lrc.isBlank()) {
            toast("Lirik masih kosong")
            return
        }
        val eco = ecoCb.isChecked
        buildBtn.isEnabled = false
        openBtn.visibility = View.GONE
        bar.progress = 0
        status("Mengubah lagu ke WAV...")
        thread {
            val wav = File(cacheDir, "song.wav")
            try {
                val r = AudioConverter.toWav(this, au, wav, eco) { p -> runOnUiThread { bar.progress = p * 85 / 100 } }
                status("Menyusun add-on...")
                val res = AddonBuilder.build(this, ad, wav, title, artist, lrc, r.durationSec)
                runOnUiThread { bar.progress = 95 }
                val uri = saveToDownloads(res.file, res.fileName)
                res.file.delete()
                runOnUiThread {
                    outUri = uri
                    outName = res.fileName
                    bar.progress = 100
                    buildStatus.text = "Selesai! ${res.songId} masuk ke Download/${res.fileName}" +
                        (if (res.notes.isEmpty()) "" else "\n" + res.notes.joinToString("\n"))
                    openBtn.visibility = View.VISIBLE
                    buildBtn.isEnabled = true
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    buildStatus.text = "Gagal: ${e.message ?: e.javaClass.simpleName}"
                    buildBtn.isEnabled = true
                }
            } finally {
                wav.delete()
            }
        }
    }

    private fun saveToDownloads(f: File, name: String): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            ?: throw java.io.IOException("Gagal membuat file di folder Download")
        contentResolver.openOutputStream(uri)!!.use { os -> f.inputStream().use { it.copyTo(os) } }
        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        return uri
    }

    private fun openInMinecraft() {
        val u = outUri ?: return
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(u, "application/octet-stream")
            setPackage("com.mojang.minecraftpe")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Buka manual dari app Files: Download/$outName")
        }
    }
}
