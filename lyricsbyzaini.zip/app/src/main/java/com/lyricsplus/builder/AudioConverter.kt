package com.lyricsplus.builder

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Ubah audio apa pun yang bisa diputar Android (mp3, m4a, aac, ogg, flac, wav) jadi WAV 16-bit.
 * Minecraft Bedrock hanya mendukung .ogg, .wav, dan .fsb, jadi mp3/m4a harus dikonversi.
 */
object AudioConverter {
    class Result(val durationSec: Int)

    private class PcmReader(f: File, private val ch: Int) : Closeable {
        private val ins = FileInputStream(f)
        private val bytes = ByteArray(ch * 2 * 8192)
        private val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        private var avail = 0
        private var idx = 0

        fun next(dst: FloatArray): Boolean {
            if (idx >= avail) {
                var n = 0
                while (n < bytes.size) {
                    val r = ins.read(bytes, n, bytes.size - n)
                    if (r < 0) break
                    n += r
                }
                avail = n / (ch * 2)
                idx = 0
                if (avail == 0) return false
            }
            val base = idx * ch * 2
            for (c in 0 until ch) dst[c] = bb.getShort(base + c * 2).toFloat()
            idx++
            return true
        }

        override fun close() = ins.close()
    }

    private fun avg(x: FloatArray, n: Int): Float {
        var s = 0f
        for (k in 0 until n) s += x[k]
        return s / n
    }

    /** eco = true: mono 22,05 kHz (file kecil). eco = false: 44,1 kHz (stereo kalau sumbernya stereo). */
    fun toWav(ctx: Context, src: Uri, out: File, eco: Boolean, progress: (Int) -> Unit): Result {
        val raw = File(out.parentFile, "decoded.pcm")
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        var srcRate = 44100
        var srcCh = 2
        var frames = 0L
        try {
            ex.setDataSource(ctx, src, null)
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    ex.selectTrack(i)
                    fmt = f
                    break
                }
            }
            if (fmt == null) throw IOException("File ini tidak berisi audio")
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val totalUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            srcCh = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            var floatPcm = false
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var lastPct = -1

            BufferedOutputStream(FileOutputStream(raw), 1 shl 16).use { rawOut ->
                var tmp = ByteArray(0)
                while (!outDone) {
                    if (!inDone) {
                        val ii = c.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val buf = c.getInputBuffer(ii)!!
                            val n = ex.readSampleData(buf, 0)
                            if (n < 0) {
                                c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inDone = true
                            } else {
                                val pts = ex.sampleTime
                                c.queueInputBuffer(ii, 0, n, pts, 0)
                                if (totalUs > 0) {
                                    val pct = (pts * 70 / totalUs).toInt().coerceIn(0, 70)
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        progress(pct)
                                    }
                                }
                                ex.advance()
                            }
                        }
                    }
                    val oi = c.dequeueOutputBuffer(info, 10_000)
                    if (oi >= 0) {
                        if (info.size > 0) {
                            val ob = c.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            if (floatPcm) {
                                val fb = ob.order(ByteOrder.nativeOrder()).asFloatBuffer()
                                val n = fb.remaining()
                                if (tmp.size < n * 2) tmp = ByteArray(n * 2)
                                val bb = ByteBuffer.wrap(tmp).order(ByteOrder.LITTLE_ENDIAN)
                                for (k in 0 until n) {
                                    val v = (fb.get() * 32767f).toInt().coerceIn(-32768, 32767)
                                    bb.putShort(k * 2, v.toShort())
                                }
                                rawOut.write(tmp, 0, n * 2)
                                frames += n / srcCh
                            } else {
                                if (tmp.size < info.size) tmp = ByteArray(info.size)
                                ob.get(tmp, 0, info.size)
                                rawOut.write(tmp, 0, info.size)
                                frames += info.size / (2 * srcCh)
                            }
                        }
                        c.releaseOutputBuffer(oi, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val nf = c.outputFormat
                        srcRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        srcCh = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        floatPcm = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                }
            }
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }

        try {
            if (frames <= 0L || srcCh <= 0) throw IOException("Audio kosong atau formatnya tidak didukung")
            val outCh = if (eco || srcCh == 1) 1 else 2
            val outRate = if (eco) 22050 else 44100
            val ratio = srcRate.toDouble() / outRate
            val totalOut = (frames / ratio).toLong()
            val dataBytes = totalOut * outCh * 2

            BufferedOutputStream(FileOutputStream(out), 1 shl 16).use { w ->
                val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                h.put("RIFF".toByteArray())
                h.putInt((36 + dataBytes).toInt())
                h.put("WAVE".toByteArray())
                h.put("fmt ".toByteArray())
                h.putInt(16)
                h.putShort(1.toShort())
                h.putShort(outCh.toShort())
                h.putInt(outRate)
                h.putInt(outRate * outCh * 2)
                h.putShort((outCh * 2).toShort())
                h.putShort(16.toShort())
                h.put("data".toByteArray())
                h.putInt(dataBytes.toInt())
                w.write(h.array())

                PcmReader(raw, srcCh).use { r ->
                    val a = FloatArray(srcCh)
                    val b = FloatArray(srcCh)
                    if (!r.next(a)) throw IOException("Audio kosong")
                    if (!r.next(b)) System.arraycopy(a, 0, b, 0, srcCh)
                    var idxA = 0L
                    val chunk = ByteBuffer.allocate(8192 * outCh * 2).order(ByteOrder.LITTLE_ENDIAN)
                    var i = 0L
                    while (i < totalOut) {
                        val pos = i * ratio
                        val fl = pos.toLong()
                        while (idxA < fl) {
                            System.arraycopy(b, 0, a, 0, srcCh)
                            r.next(b)
                            idxA++
                        }
                        val frac = (pos - idxA).toFloat()
                        for (c in 0 until outCh) {
                            val sa = if (outCh == 1) avg(a, srcCh) else a[c]
                            val sb = if (outCh == 1) avg(b, srcCh) else b[c]
                            val v = (sa + (sb - sa) * frac).toInt().coerceIn(-32768, 32767)
                            chunk.putShort(v.toShort())
                        }
                        if (!chunk.hasRemaining()) {
                            w.write(chunk.array(), 0, chunk.position())
                            chunk.clear()
                        }
                        if (i % 50000L == 0L) progress(70 + (i * 30 / totalOut).toInt())
                        i++
                    }
                    if (chunk.position() > 0) w.write(chunk.array(), 0, chunk.position())
                }
            }
            return Result(((totalOut + outRate - 1) / outRate).toInt())
        } finally {
            raw.delete()
        }
    }
}
